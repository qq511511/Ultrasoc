class LogManager {
    constructor() {
        this.baseUrl = 'http://localhost:8078';
        this.init();
    }

    init() {
        this.bindEvents();
        this.checkServerStatus();
        this.loadLogList();
    }

    bindEvents() {
        document.getElementById('refreshBtn').addEventListener('click', () => {
            this.loadLogList();
        });

        document.getElementById('clearAllBtn').addEventListener('click', () => {
            this.clearAllLogs();
        });

        document.getElementById('startServerBtn').addEventListener('click', () => {
            this.startServer();
        });

        document.getElementById('stopServerBtn').addEventListener('click', () => {
            this.stopServer();
        });

        document.getElementById('closeViewer').addEventListener('click', () => {
            this.hideLogViewer();
        });
    }

    async checkServerStatus() {
        try {
            const response = await fetch(`${this.baseUrl}/api/logs/list`);
            if (response.ok) {
                this.updateServerStatus(true);
            } else {
                this.updateServerStatus(false);
            }
        } catch (error) {
            this.updateServerStatus(false);
        }
    }

    updateServerStatus(online) {
        const statusElement = document.getElementById('serverStatus');
        if (online) {
            statusElement.textContent = '服务状态: 在线';
            statusElement.className = 'status-online';
        } else {
            statusElement.textContent = '服务状态: 离线';
            statusElement.className = 'status-offline';
        }
    }

    async loadLogList() {
        try {
            const response = await fetch(`${this.baseUrl}/api/logs/list`);
            const logs = await response.json();
            this.renderLogTable(logs);
        } catch (error) {
            this.showError('无法加载日志列表: ' + error.message);
        }
    }

    renderLogTable(logs) {
        const tbody = document.getElementById('logTableBody');
        tbody.innerHTML = '';

        document.getElementById('logCount').textContent = `日志文件: ${logs.length} 个`;

        logs.forEach(log => {
            const row = document.createElement('tr');
            
            row.innerHTML = `
                <td>${this.escapeHtml(log.name)}</td>
                <td>${this.formatFileSize(log.size)}</td>
                <td>${this.escapeHtml(log.date)}</td>
                <td>
                    <button class="btn btn-primary btn-sm" onclick="logManager.viewLog('${this.escapeHtml(log.name)}')">查看</button>
                    <button class="btn btn-danger btn-sm" onclick="logManager.deleteLog('${this.escapeHtml(log.name)}')">删除</button>
                </td>
            `;
            
            tbody.appendChild(row);
        });
    }

    async viewLog(filename) {
        try {
            const response = await fetch(`${this.baseUrl}/api/logs/view?file=${encodeURIComponent(filename)}`);
            const content = await response.text();
            
            document.getElementById('viewerTitle').textContent = `正在查看: ${filename}`;
            document.getElementById('logContent').textContent = content;
            document.getElementById('logViewer').style.display = 'block';
            
            // 滚动到查看器
            document.getElementById('logViewer').scrollIntoView({ behavior: 'smooth' });
        } catch (error) {
            this.showError('无法加载日志内容: ' + error.message);
        }
    }

    async deleteLog(filename) {
        if (confirm(`确定要删除日志文件 "${filename}" 吗？`)) {
            try {
                const response = await fetch(`${this.baseUrl}/api/logs/delete?file=${encodeURIComponent(filename)}`, {
                    method: 'DELETE'
                });
                
                if (response.ok) {
                    this.showSuccess('日志文件已删除');
                    this.loadLogList();
                } else {
                    this.showError('删除失败');
                }
            } catch (error) {
                this.showError('删除失败: ' + error.message);
            }
        }
    }

    async clearAllLogs() {
        if (confirm('确定要删除所有日志文件吗？此操作不可恢复！')) {
            try {
                const response = await fetch(`${this.baseUrl}/api/logs/clear-all`, {
                    method: 'DELETE'
                });
                
                if (response.ok) {
                    this.showSuccess('所有日志文件已清理');
                    this.loadLogList();
                } else {
                    this.showError('清理失败');
                }
            } catch (error) {
                this.showError('清理失败: ' + error.message);
            }
        }
    }

    async startServer() {
        // 这里可以调用后端API启动服务器
        this.showSuccess('服务器启动命令已发送');
        setTimeout(() => this.checkServerStatus(), 2000);
    }

    async stopServer() {
        // 这里可以调用后端API停止服务器
        this.showSuccess('服务器停止命令已发送');
        setTimeout(() => this.checkServerStatus(), 2000);
    }

    hideLogViewer() {
        document.getElementById('logViewer').style.display = 'none';
    }

    formatFileSize(bytes) {
        if (bytes === 0) return '0 B';
        const k = 1024;
        const sizes = ['B', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    escapeHtml(unsafe) {
        return unsafe
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }

    showError(message) {
        alert('错误: ' + message);
    }

    showSuccess(message) {
        alert('成功: ' + message);
    }
}

// 初始化日志管理器
const logManager = new LogManager();

// 定期检查服务器状态
setInterval(() => {
    logManager.checkServerStatus();
}, 30000);