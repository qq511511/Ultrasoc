#!/system/bin/sh

MODDIR="${0%/*}"

# 只设置基本权限
chmod 755 "$MODDIR"/*.sh 2>/dev/null
chmod -R 644 "$MODDIR"/modules/*.zip 2>/dev/null
chmod -R 644 "$MODDIR"/apps/*.apk 2>/dev/null

exit 0
