#!/system/bin/sh
SKIPUNZIP=1
MODDIR="${0%/*}"
LOG_FILE="/data/adb/ksu_batch_install.log"

# 等待系统完全启动
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 5
done

sleep 15  # 额外等待确保稳定

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}

# 直接解压安装模块（不使用ksu命令）
install_module_direct() {
    local module_num="$1"
    local module_zip="$MODDIR/modules/$module_num.zip"
    local module_name="模块$module_num"
    
    log "📦 安装$module_name..."
    
    # 检查文件是否存在
    if [ ! -f "$module_zip" ]; then
        log "❌ 文件不存在: $module_num.zip"
        return 1
    fi
    
    # 创建临时目录
    local temp_dir="/data/local/tmp/module_$module_num"
    rm -rf "$temp_dir"
    mkdir -p "$temp_dir"
    
    # 解压ZIP文件
    if ! unzip -q "$module_zip" -d "$temp_dir" 2>/dev/null; then
        log "❌ 解压失败: $module_num.zip"
        rm -rf "$temp_dir"
        return 1
    fi
    
    # 检查模块结构
    if [ ! -f "$temp_dir/module.prop" ]; then
        log "❌ 无效模块: 缺少module.prop"
        rm -rf "$temp_dir"
        return 1
    fi
    
    # 获取模块ID
    local module_id=$(grep "^id=" "$temp_dir/module.prop" | head -1 | cut -d'=' -f2)
    if [ -z "$module_id" ]; then
        module_id="module_$module_num"
    fi
    
    local target_dir="/data/adb/modules/$module_id"
    
    # 清理旧模块
    if [ -d "$target_dir" ]; then
        rm -rf "$target_dir"
        log "⚠️ 清理旧模块: $module_id"
    fi
    
    # 复制文件到模块目录
    mkdir -p "$target_dir"
    if cp -r "$temp_dir"/* "$target_dir"/ 2>/dev/null; then
        # 设置权限
        find "$target_dir" -name "*.sh" -exec chmod 755 {} \; 2>/dev/null
        chown -R root:root "$target_dir" 2>/dev/null
        
        # 验证安装
        if [ -f "$target_dir/module.prop" ]; then
            local real_name=$(grep "^name=" "$target_dir/module.prop" | head -1 | cut -d'=' -f2)
            log "✅ 安装成功: ${real_name:-$module_id}"
            rm -rf "$temp_dir"
            return 0
        fi
    fi
    
    log "❌ 复制文件失败: $module_name"
    rm -rf "$temp_dir" "$target_dir"
    return 1
}

# 应用安装
install_app_with_retry() {
    local app_num="$1"
    local apk_file="$MODDIR/apps/$app_num.apk"
    local app_name="应用$app_num"
    
    log "📱 安装$app_name..."
    
    if [ ! -f "$apk_file" ]; then
        log "❌ APK不存在: $app_num.apk"
        return 1
    fi
    
    # 重试3次
    for i in 1 2 3; do
        # 使用不同的安装方法
        local result
        if [ $i -eq 1 ]; then
            result=$(pm install -r "$apk_file" 2>&1)
        elif [ $i -eq 2 ]; then
            # 尝试不使用-r参数
            result=$(pm install "$apk_file" 2>&1)
        else
            # 最后尝试使用cmd package install
            result=$(cmd package install "$apk_file" 2>&1)
        fi
        
        if echo "$result" | grep -q "Success"; then
            log "✅ $app_name 安装成功 (尝试$i)"
            return 0
        else
            log "⚠️ $app_name 尝试$i失败: $result"
            sleep 3
        fi
    done
    
    log "❌ $app_name 安装失败"
    return 1
}

# 主安装流程
main() {
    log "========================================"
    log "🎯 开始批量安装 - 直接解压方式"
    log "========================================"
    
    local module_success=0
    local app_success=0
    
    # 安装模块1-7
    for i in 1 2 3 4 5 6 7; do
        if install_module_direct $i; then
            module_success=$((module_success + 1))
        fi
        sleep 2
    done
    
    # 等待更长时间确保包管理器就绪
    log "⏳ 等待包管理器就绪..."
    sleep 10
    
    # 安装应用
    for i in 1 2; do
        if install_app_with_retry $i; then
            app_success=$((app_success + 1))
        fi
        sleep 2
    done
    
    log "📊 安装完成: $module_success/7 个模块, $app_success/2 个应用"
    
    # 创建完成标记
    echo "modules:$module_success apps:$app_success" > "$MODDIR/.installed"
    
    # 发送简单通知（避免复杂命令）
    setprop persist.batch.install.complete true 2>/dev/null
    
    log "🎉 安装流程结束"

MODDIR="${0%/*}"
LOG_FILE="/data/adb/ksu_batch_install.log"

# 等待系统启动
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 5
done

sleep 15

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}

# 安装KSU WebUI应用
install_ksu_webui() {
    local apk_file="$MODDIR/apps/3.apk"
    
    if [ ! -f "$apk_file" ]; then
        log "❌ KSU WebUI APK不存在"
        return 1
    fi
    
    log "📱 安装KSU WebUI..."
    
    # 尝试多种安装方法
    if pm install -r "$apk_file" >/dev/null 2>&1; then
        log "✅ KSU WebUI安装成功"
        return 0
    else
        # 备用安装方法
        if cmd package install "$apk_file" >/dev/null 2>&1; then
            log "✅ KSU WebUI安装成功(备用方法)"
            return 0
        else
            log "❌ KSU WebUI安装失败"
            return 1
        fi
    fi
}

# 启动WebUI服务器
start_webui_server() {
    log "🚀 启动WebUI服务器..."
    
    chmod 755 "$MODDIR/bin/webui_server.sh"
    nohup "$MODDIR/bin/webui_server.sh" >/dev/null 2>&1 &
    
    log "✅ WebUI服务器已启动，访问: http://localhost:8078"
}

    log "========================================"
    log "🎯 开始安装流程 - 包含WebUI"
    log "========================================"
    
    # 安装KSU WebUI
    install_ksu_webui
    
    # 启动Web服务器
    start_webui_server
    
    log "🎉 安装完成! WebUI已集成"
    log ""
    log "=========分割线=========="
    log ""

}
ui_print "**********************"
ui_print "释放文件中..."
sleep 0.5
ui_print "正在安装模块中..."
sleep 0.5
main
ui_print "安装完成 !"
sleep 0.1
ui_print "正在打开酷安..."
sleep 0.1
ui_print "点个关注呗 !"
sleep 0.1
rm -rf /data/adb/modules/Ultra_soc_fuckAndroid/必看.txt
rm -rf /data/adb/modules_update/Ultra_soc_fuckAndroid/必看.txt
am start -a android.intent.action.VIEW -d "http://www.coolapk.com/u/33881454"