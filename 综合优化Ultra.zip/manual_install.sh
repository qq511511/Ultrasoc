#!/system/bin/sh

# 手动触发安装
/data/adb/modules/Ultra_soc_fuckAndroid/service.sh
echo "手动安装已触发"
echo "查看日志: tail -f /data/adb/ksu_batch_install.log"
