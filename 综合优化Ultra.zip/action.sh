#!/system/bin/sh
# 酷安@MineACE

echo "****** 提示 *******"
echo " "
echo "即将开始清理日志..."
sleep 0.1
echo "倒计时: 5..."
sleep 1
echo "倒计时: 4...."
sleep 1
echo "倒计时: 3..."
sleep 1
echo "倒计时: 2..."
sleep 1
echo "倒计时: 1..."
sleep 1
echo "倒计时: 0..."
sleep 0.1
rm -rf /data/adb/ksu_batch_install.log
rm -rf /data/adb/module_bundle_install.log
echo "清理完成..."
echo ""
echo "******************"